﻿using UnityEngine;
using UnityEngine.UI;

public abstract class Building : MonoBehaviour
{
    public abstract void OnUpdate();
    public abstract void OnStart();
    public abstract void MyOnDestroy();
    public int cost;
    public int energyChange;
    public float health;
    private float max_health;
    public float health_decrease;
    public int index;
    public Image healthBar;

    private void Destroy()
    {
        Planet.currentPlanet.buildingSpots[index].building = null;
        MyOnDestroy();
        Destroy(gameObject);
    }

    private void Start()
    {
        max_health = health;
        OnStart();
    }

    private void Update()
    {
        health -= health_decrease * Time.deltaTime;
        healthBar.fillAmount = health / max_health;
        if (health < 0)
            Destroy();
        OnUpdate();
    }

}
