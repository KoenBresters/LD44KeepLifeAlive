﻿using UnityEngine;
using UnityEngine.UI;

public class Planet : MonoBehaviour
{
    public static Planet currentPlanet;
    public float rotation_speed;
    public float LP = 0;
    public float LP_change_rate = 0.0000001f;
    public float temperature = 20;
    public float water = 50;
    public float toxic_gas = 0;
    public int buildingSpotCount = 10;
    public float c;
    public float temperature_importance;
    public float water_importance;
    public float toxic_importance;
    public float water_dampening_speed;
    public float water_dampening_threshold;
    public float global_warming_rate;
    public float global_warming_threshold;
    public float natural_cooling_rate;
    public float natural_toxic_decrease_rate;
    public BuildingSpot[] buildingSpots;
    public GameObject BuildingspotPrefab;
    public GameObject[] BuildingTypes;
    public GameObject[] BuildingButtons;
    public int build_index;
    public GameObject BuildingCursor;
    public int energyProduction;
    public int energyUse;
    public bool enough_energy;
    public AnimationCurve meteor_probability;
    public float AnimationCurveEndTime;
    public GameObject meteorPrefab;
    public AnimationCurve meteor_probability2;
    public float AnimationCurveEndTime2;
    public GameObject meteorPrefab2;
    public Text LPText;
    public Text TemperatureText;
    public Text WaterText;
    public Text ToxicText;
    public Text ProductionText;
    public Text UseText;
    public GameObject PlantPrefab;
    public PlantSpecies[] plants;
    public AnimationCurve CloudChanceForToxic;
    public AnimationCurve AlphaForToxic;
    public GameObject ToxicCloudPrefab;
    public Transform noScale;
    public LineRenderer[] rivers;
    public AnimationCurve RiverSizeForWater;
    public AnimationCurve OceonForWater;
    public Gradient TemperatureColor;
    public float gradient_min;
    public float gradient_max;
    public new SpriteRenderer renderer;
    public GameObject DeathScreen;
    public Text TimeDisplay;
    public Text scoreDisplay;
    private float score = -1f;
    private Color brown;

    [System.Serializable]
    public struct PlantSpecies
    {
        public AnimationCurve chance_for_temperature;
        public Sprite sprite;
    }

    // Start is called before the first frame update
    void Start()
    {
        brown = renderer.color;
        currentPlanet = this;
        buildingSpots = new BuildingSpot[buildingSpotCount];
        for (int i = 0; i < buildingSpotCount; i++)
        {
            float angle = i / (float)buildingSpotCount * 2 * Mathf.PI;
            Vector2 position = new Vector2(10 * Mathf.Cos(angle), 10 * Mathf.Sin(angle));
            buildingSpots[i] = Instantiate(BuildingspotPrefab, position, Quaternion.FromToRotation(Vector2.right, position / 10f)).GetComponent<BuildingSpot>();
            buildingSpots[i].angle = angle;
            buildingSpots[i].index = i;
            buildingSpots[i].building = null;
            buildingSpots[i].collider = buildingSpots[i].GetComponentInChildren<Collider2D>();
            buildingSpots[i].transform.SetParent(transform);
        }

        for (int i = 0; i < BuildingButtons.Length; i++)
        {
            BuildingButtons[i].GetComponentsInChildren<Text>()[0].text = "Cost: " + BuildingTypes[i].GetComponent<Building>().cost.ToString() + " Life";
            int e = BuildingTypes[i].GetComponent<Building>().energyChange;
            BuildingButtons[i].GetComponentsInChildren<Text>()[1].text = "Energy: " + ((e < 0)? "" : "+") + e.ToString();
        }
    }

    // Update is called once per frame
    void Update()
    {
        transform.rotation *= Quaternion.Euler(0f, 0f, rotation_speed * Time.deltaTime);

        float dLPdt = LP_change_rate * (LP * (c + water*water_importance-toxic_importance*toxic_gas) * (1e6f - LP)
            - LP*(Mathf.Pow(20 - temperature, 2) * temperature_importance + toxic_importance * toxic_gas));
        LP += dLPdt * Time.deltaTime;
        if (temperature > water_dampening_threshold)
            water -= (temperature - water_dampening_threshold) * water_dampening_speed * water *Time.deltaTime;
        if (toxic_gas > global_warming_threshold)
            temperature += ((toxic_gas - global_warming_threshold) * global_warming_rate) * Time.deltaTime;
        temperature -= natural_cooling_rate * (temperature - 20) * Time.deltaTime;
        if (toxic_gas > 0)
            toxic_gas = Mathf.Max(0f, toxic_gas - natural_toxic_decrease_rate * Time.deltaTime);
        
        int x = 0;
        energyProduction = 0;
        energyUse = 0;
        foreach (BuildingSpot building in buildingSpots)
        {
            if (building.building)
            {
                x += building.building.energyChange;
                if (building.building.energyChange > 0)
                    energyProduction += building.building.energyChange;
                else
                    energyUse -= building.building.energyChange;
            }
        }
        enough_energy = x >= 0;

        LPText.text = Mathf.RoundToInt(LP).ToString();
        TemperatureText.text = Mathf.RoundToInt(temperature).ToString();
        WaterText.text = Mathf.RoundToInt(water).ToString();
        ToxicText.text = Mathf.RoundToInt(toxic_gas).ToString();
        ProductionText.text = "+" + Mathf.RoundToInt(energyProduction).ToString();
        UseText.text = "-" + Mathf.RoundToInt(energyUse).ToString();
        
        if(Random.value < ((Time.timeSinceLevelLoad < AnimationCurveEndTime)? meteor_probability.Evaluate(Time.timeSinceLevelLoad / AnimationCurveEndTime) : meteor_probability.Evaluate(0)))
        {
            Vector2 p = 50 * Random.insideUnitCircle;
            p = p.normalized * (50 + p.magnitude);
            Rigidbody2D r = Instantiate(meteorPrefab, p, Quaternion.identity).GetComponent<Rigidbody2D>();
            r.AddForce(-p.normalized * Random.Range(5, 20f) + 2.5f * Random.insideUnitCircle, ForceMode2D.Impulse);
        }

        if (Random.value < ((Time.timeSinceLevelLoad < AnimationCurveEndTime2) ? meteor_probability2.Evaluate(Time.timeSinceLevelLoad / AnimationCurveEndTime2) : meteor_probability2.Evaluate(0)))
        {
            Vector2 p = 50 * Random.insideUnitCircle;
            p = p.normalized * (50 + p.magnitude);
            Rigidbody2D r = Instantiate(meteorPrefab2, p, Quaternion.identity).GetComponent<Rigidbody2D>();
            r.AddForce(-p.normalized * Random.Range(5*5, 100f) + 2.5f * Random.insideUnitCircle, ForceMode2D.Impulse);
        }

        foreach (PlantSpecies p in plants)
            if (Random.value < p.chance_for_temperature.Evaluate(temperature)*(LP/1e6))
            {
                float angle = Random.value * 2 * Mathf.PI;
                Vector2 position = new Vector2(10 * Mathf.Cos(angle), 10 * Mathf.Sin(angle));
                GameObject pl = Instantiate(PlantPrefab, position, Quaternion.FromToRotation(Vector2.right, position / 10f));
                pl.GetComponentInChildren<SpriteRenderer>().sprite = p.sprite;
                pl.transform.SetParent(noScale);
            }

        if (Random.value < CloudChanceForToxic.Evaluate(toxic_gas))
        {
            float angle = Random.value * 2 * Mathf.PI;
            Vector2 position = new Vector2(10 * Mathf.Cos(angle), 10 * Mathf.Sin(angle));
            GameObject pl = Instantiate(ToxicCloudPrefab, position, Quaternion.FromToRotation(Vector2.right, position / 10f));
            pl.GetComponentInChildren<SpriteRenderer>().color = new Color(1f, 1f, 1f, AlphaForToxic.Evaluate(toxic_gas));
            pl.transform.SetParent(noScale);
        }

        renderer.color = Color.Lerp(Color.Lerp(brown, TemperatureColor.Evaluate(Mathf.Clamp01((temperature - gradient_min) / (gradient_max - gradient_min))), LP / 1e6f), 
            Color.blue, OceonForWater.Evaluate(water));

        foreach (LineRenderer l in rivers)
            l.widthCurve = AnimationCurve.Constant(0, 10000, RiverSizeForWater.Evaluate(water));

        if (LP < 0)
        {
            DeathScreen.SetActive(true);
            if (score == -1)
                score = Mathf.RoundToInt(Time.timeSinceLevelLoad);
            scoreDisplay.text = "Score: " + score.ToString();
        }

        if (score == -1)
            TimeDisplay.text = "Score: " + Mathf.RoundToInt(Time.timeSinceLevelLoad).ToString();

        if (Input.GetMouseButtonDown(0))
        {
            Vector2 z = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            for (int i = 0; i < buildingSpotCount; i++)
            {
                if (buildingSpots[i].collider.OverlapPoint(z)) {
                    TryAddBuilding(i);
                    return;
                }
            }
        }
    }

    public void SetBuildIndex(int index)
    {
        BuildingCursor.transform.position = Vector3.up * 80f + BuildingButtons[index].transform.position;
        build_index = index;
    }

    public void MainMenu()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(0);
    }

    public void TryAddBuilding(int index)
    {
        GameObject Prefab = BuildingTypes[build_index];
        BuildingSpot buildingSpot = buildingSpots[index];
        if (buildingSpot.building == null && LP > Prefab.GetComponent<Building>().cost)
        {
            buildingSpot.building = Instantiate(Prefab, buildingSpot.transform, false).GetComponent<Building>();
            buildingSpot.building.index = index;
            LP -= buildingSpot.building.cost;
            AudioManager.PlaySound("Build");
        }
    }
}
