﻿using UnityEngine;

public class SolarPanel : Building
{
    public float coolrate;

    public override void MyOnDestroy()
    {
        
    }

    public override void OnStart()
    {
        
    }

    public override void OnUpdate()
    {
        Planet.currentPlanet.temperature -= coolrate * Time.deltaTime;
    }
}
