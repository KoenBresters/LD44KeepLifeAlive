﻿using UnityEngine;

public class BioFuelReactor : Building
{
    public float pollution_rate;
    public float LP_use_rate;
    public override void MyOnDestroy()
    {
        
    }

    public override void OnStart()
    {
        
    }
    public override void OnUpdate()
    {
        Planet.currentPlanet.LP -= LP_use_rate * Time.deltaTime;
        Planet.currentPlanet.toxic_gas += pollution_rate * Time.deltaTime;
    }
}
