﻿using UnityEngine;

public class Meteor : MonoBehaviour
{
    public float impact_temperature;
    public float impact_LP;
    public float destroy_LP;
    public float water;
    public float health;
    private void Update()
    {
        if (transform.position.sqrMagnitude > 10000)
            Destroy(gameObject);
    }

    private void destroy()
    {
        Planet.currentPlanet.LP += destroy_LP;
        ParticleManager.current.PlayParticle("MeteorExplosion", transform.position, Quaternion.identity);
        AudioManager.PlaySound("MeteorExplosion");
        Destroy(gameObject);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Planet"))
        {
            Planet.currentPlanet.temperature += impact_temperature;
            Planet.currentPlanet.LP -= impact_LP;
            Planet.currentPlanet.water += water;
            ParticleManager.current.PlayParticle("MeteorExplosion", transform.position, Quaternion.identity);
            AudioManager.PlaySound("MeteorExplosion");
            Destroy(gameObject);
        }
        else if (collision.gameObject.CompareTag("Projectile"))
        {
            health -= collision.gameObject.GetComponent<Projectile>().damage;
            Destroy(collision.gameObject);
            if (health < 0)
                destroy();
            
        }
    }
}
