﻿using UnityEngine;
using System.Collections.Generic;

public class ParticleManager : MonoBehaviour
{
    [System.Serializable]
    public struct Particle
    {
        public string name;
        public GameObject prefab;
    }

    public static ParticleManager current;

    public Particle[] particles;
    private Dictionary<string, GameObject> particle_refrences;

    private void Awake()
    {
        current = this;
        particle_refrences = new Dictionary<string, GameObject>();
        foreach (Particle p in particles)
        {
            particle_refrences.Add(p.name, p.prefab);
        }
    }

    public void PlayParticle(string name, Vector3 at, Quaternion rotation)
    {
        Instantiate(particle_refrences[name], at, rotation);
    }
}
