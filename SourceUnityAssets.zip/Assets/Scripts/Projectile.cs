﻿using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float damage;
    private void Update()
    {
        if (transform.position.sqrMagnitude > 10000)
            Destroy(gameObject);
    }
}
