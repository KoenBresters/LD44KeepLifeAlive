﻿using UnityEngine;

public class BuildingSpot : MonoBehaviour
{
    public float angle;
    public Building building;
    public int index;
    public new Collider2D collider;
}
