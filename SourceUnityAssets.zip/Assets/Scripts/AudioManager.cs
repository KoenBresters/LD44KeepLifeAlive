﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class AudioManager : MonoBehaviour {

    [System.Serializable]
    public class Sound {
        public string name;
        public AudioClip hi;
        public int instances;
        [Range(0f, 1f)]
        public float volume = .5f;
        [Range(-3f, 3f)]
        public float pitch = 1f;
        [Range(0f, 1f)]
        public float spatialBlend = 1f;
    }
    public Sound[] sounds;
    Dictionary<string, List<GameObject>> refrences;
    public GameObject SoundPrefab;
    public static AudioManager current;


    private void Awake()
    {
        if (current)
        {
            Destroy(gameObject);
            return;
        }else
        {
            current = this;
            DontDestroyOnLoad(gameObject);
        }
        refrences = new Dictionary<string, List<GameObject>>();
        foreach (Sound s in sounds)
        {
            List<GameObject> l = new List<GameObject>();
            for (int i = 0; i < s.instances; i++)
            {
                AudioSource a = Instantiate(SoundPrefab, transform).GetComponent<AudioSource>();
                a.volume = s.volume;
                a.pitch = s.pitch;
                a.spatialBlend = s.spatialBlend;
                a.clip = s.hi;
                l.Add(a.gameObject);
            }
            refrences.Add(s.name, l);
        }
    }
    public static AudioSource PlaySound(string name, Vector3 position)
    {
        List<GameObject> sound_positions = current.refrences[name];
        foreach (GameObject i in sound_positions)
        {
            AudioSource a = i.GetComponent<AudioSource>();
            if (!a.isPlaying)
            {
                a.Play();
                a.transform.position = position;
                return a;
            }
            
        }
        Debug.LogWarning("not enough instances");
        return null;
    }

    public static void PlaySound(string name)
    {
        List<GameObject> sound_positions = current.refrences[name];
        foreach (GameObject i in sound_positions)
        {
            AudioSource a = i.GetComponent<AudioSource>();
            if (!a.isPlaying)
            {
                a.Play();
                a.transform.localPosition = Vector3.zero;
                return;
            }

        }
        Debug.LogWarning("not enough instances");
    }

    public static AudioSource LoopSoundOnObject(string name, GameObject obj)
    {
        foreach (Sound s in current.sounds)
            if (s.name == name)
            {
                AudioSource a = obj.AddComponent<AudioSource>();
                a.volume = s.volume;
                a.pitch = s.pitch;
                a.spatialBlend = s.spatialBlend;
                a.clip = s.hi;
                a.loop = true;

                return a;
            }
        throw new System.Exception("name not found");
    }

    public static void FadeOutSound(AudioSource sound, float length)
    {
        current.StartCoroutine(current.FadeOut(sound, length));
    }

    public IEnumerator FadeOut(AudioSource source, float time)
    {
        try
        {
            float startTime = Time.time;
            float endTime = startTime + time;
            float oldVolume = source.volume;
            while (Time.time < endTime)
            {
                source.volume = oldVolume * (1 - (Time.time - startTime) / (endTime - startTime));
                yield return new WaitForEndOfFrame();
            }
            if (source.transform.parent == transform)
                source.volume = oldVolume;
            else
                Destroy(source.gameObject);
        }
        finally
        {

        }
    }
}
