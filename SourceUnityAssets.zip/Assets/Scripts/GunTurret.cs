﻿using UnityEngine;

public class GunTurret : Building
{
    public float pollution_per_shot;
    public float LP_per_shot;
    public float rotate_speed;
    public float min_shoot_angle = 30f;
    public float recharge_time = 1f;
    public Transform joint;
    private Transform target;
    public float last_shoot_time;
    public GameObject projectilePrefab;
    public float projectile_spawn_distance = 3f;
    public override void MyOnDestroy()
    {

    }

    public override void OnStart()
    {

    }

    public override void OnUpdate()
    {
        if (target && Planet.currentPlanet.enough_energy)
        {
            float angle = Vector2.SignedAngle(joint.right, (target.position - joint.position).normalized);
            joint.localRotation = Quaternion.Euler(0f, 0f, ((angle > 0) ?1 : -1) * rotate_speed * Time.deltaTime) * joint.localRotation;
            if(Mathf.Abs(angle) < min_shoot_angle && Time.time-last_shoot_time > recharge_time)
            {
                last_shoot_time = Time.time;
                Shoot();
            }
        }
        
    }

    private void Shoot()
    {
        Rigidbody2D r = Instantiate(projectilePrefab, joint.position+joint.right*projectile_spawn_distance, Quaternion.identity).GetComponent<Rigidbody2D>();
        Planet.currentPlanet.toxic_gas += pollution_per_shot;
        r.AddForce(joint.right * 10f, ForceMode2D.Impulse);
        AudioManager.PlaySound("GunFire");
    }

    private void OnTriggerStay2D(Collider2D collision)
    {

        if (!target || (collision.gameObject.CompareTag("Meteor") && 
            (collision.transform.position - transform.position).sqrMagnitude < (target.transform.position - transform.position).sqrMagnitude))
            target = collision.transform;
        
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.transform == target)
            target = null;
    }
}